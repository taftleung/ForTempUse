package com.hsbc.glcm.graphqlapi.resolvers;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InputOrderBy {

    private String field;
    
    @Enumerated(EnumType.STRING)
    private EnumOrderByDirection direction;
    
    static Sort convert(List<InputOrderBy> inputOrderByList) {
    	List<Sort.Order> orders = new ArrayList<>();
    	inputOrderByList.stream().forEach((inputOrderBy) -> orders.add(Sort.Order.by(inputOrderBy.getField()).with(getSpringDataDirection(inputOrderBy.getDirection()))));
    	
    	return Sort.by(orders);
    }
    
    static Direction getSpringDataDirection(EnumOrderByDirection direction) {
    	return direction.name().equals("ASC") ? Direction.ASC : Direction.DESC;
    }
}