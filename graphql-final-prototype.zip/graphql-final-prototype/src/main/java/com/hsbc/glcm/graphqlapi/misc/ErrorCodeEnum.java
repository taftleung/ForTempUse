package com.hsbc.glcm.graphqlapi.misc;

import lombok.Getter;

@Getter
public enum ErrorCodeEnum {
	TALK_ID_NOT_FOUND(900010, "Talk ID not found!"),
	XXX_YYY_INVALID(800050, "your custom error message");
    
    private final int errorCode;
    private final String errorMessage;
    
    ErrorCodeEnum(int errorCode, String errorMessage) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }
}