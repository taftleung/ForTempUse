package io.springtrader.consumer;

public class ProducerResponse {
    private int value;

    public void setValue(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
