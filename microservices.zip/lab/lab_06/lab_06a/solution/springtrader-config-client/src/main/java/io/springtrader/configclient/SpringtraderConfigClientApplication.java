package io.springtrader.configclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringtraderConfigClientApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringtraderConfigClientApplication.class, args);
    }

}
