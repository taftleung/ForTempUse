package io.springtrader.producer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.atomic.AtomicInteger;

@RestController
public class ProducerController {

    @Value("${server.port}")
    private int serverPort;

    private Log log = LogFactory.getLog(ProducerController.class);
    private AtomicInteger counter = new AtomicInteger(0);
    private volatile boolean sendError = false;

    @RequestMapping(value = "/", produces = "application/json")
    public String produce() {

        if (sendError) {
            // to simulate a server side error
            throw new RuntimeException("ERROR");
        }

        int value = counter.getAndIncrement();
        log.info("Produced a value: " + value);

        return String.format("{\"serverPort\":%d, \"value\":%d}", serverPort, value);
    }

    @RequestMapping("/setError/{flag}")
    String setError(@PathVariable boolean flag) {
        sendError = flag;
        return "setError = " + flag;
    }
}
