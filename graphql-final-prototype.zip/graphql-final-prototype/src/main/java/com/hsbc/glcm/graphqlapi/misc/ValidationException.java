package com.hsbc.glcm.graphqlapi.misc;

public class ValidationException extends Exception {
	
	private final int errorCode;
	private boolean suppressStacktrace = false;

	@Deprecated
    public ValidationException(int errorCode, String errorMessage, boolean suppressStacktrace) {
    	super(errorMessage, null, suppressStacktrace, !suppressStacktrace);
    	this.suppressStacktrace = suppressStacktrace;
        this.errorCode = errorCode;
    }
    
    public ValidationException(ErrorCodeEnum errorCodeEnum) {
    	super(errorCodeEnum.getErrorMessage(), null, true, !true);
    	this.suppressStacktrace = true;
        this.errorCode = errorCodeEnum.getErrorCode();
    }
    
    @Override
    public String toString() {
        if (suppressStacktrace) {
            return getLocalizedMessage();
        } else {
            return super.toString();
        }
    }
    
    public int getErrorCode() {
        return this.errorCode;
    }
}