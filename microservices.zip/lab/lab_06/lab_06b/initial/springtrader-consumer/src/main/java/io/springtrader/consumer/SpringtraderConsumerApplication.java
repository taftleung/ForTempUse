package io.springtrader.consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringtraderConsumerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringtraderConsumerApplication.class, args);
    }
}
