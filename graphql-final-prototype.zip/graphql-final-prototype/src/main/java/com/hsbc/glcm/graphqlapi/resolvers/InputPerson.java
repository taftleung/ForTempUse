package com.hsbc.glcm.graphqlapi.resolvers;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.hsbc.glcm.graphqlapi.model.Person;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InputPerson {

    private String name;
    private String blog;
    private String githubAccount;

    Person convert() {
        return convert(this);
    }

    public static Person convert(InputPerson person) {
        return person != null ? new Person(person.name, person.githubAccount, person.blog, null) : null;
    }
}
