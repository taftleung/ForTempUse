package io.pivotal.springtrader;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringTraderAppMonolith {

    public static void main(String[] args) {
        SpringApplication.run(SpringTraderAppMonolith.class, args);
    }
}
