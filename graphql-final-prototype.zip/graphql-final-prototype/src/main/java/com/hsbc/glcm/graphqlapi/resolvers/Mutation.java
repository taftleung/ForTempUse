package com.hsbc.glcm.graphqlapi.resolvers;

import com.coxautodev.graphql.tools.GraphQLMutationResolver;
import com.hsbc.glcm.graphqlapi.model.Comment;
import com.hsbc.glcm.graphqlapi.model.Conference;
import com.hsbc.glcm.graphqlapi.model.Person;
import com.hsbc.glcm.graphqlapi.model.Talk;
import com.hsbc.glcm.graphqlapi.publishers.CommentPublisher;
import com.hsbc.glcm.graphqlapi.service.CommentRepository;
import com.hsbc.glcm.graphqlapi.service.ConferenceRepository;
import com.hsbc.glcm.graphqlapi.service.PersonRepository;
import com.hsbc.glcm.graphqlapi.service.TalkRepository;
import com.hsbc.glcm.graphqlapi.misc.PermissionException;
import com.hsbc.glcm.graphqlapi.misc.ValidationException;
import com.hsbc.glcm.graphqlapi.misc.ErrorCodeEnum;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.OffsetDateTime;
import java.util.Optional;

@Component
public class Mutation implements GraphQLMutationResolver {

    @Autowired
    private PersonRepository personRepository;

    @Autowired
    private TalkRepository talkRepository;

    @Autowired
    private CommentRepository commentRepository;

    @Autowired
    private ConferenceRepository conferenceRepository;

    @Autowired
    private CommentPublisher commentPublisher;

    public Person addPerson(final InputPerson person) {
        return this.personRepository.save(person.convert());
    }

    public Talk addTalk(final InputTalk talk) {
        return this.talkRepository.save(talk.convert());
    }

    public Conference addConference(final InputConference conference) {
        return this.conferenceRepository.save(conference.convert());
    }

    public Conference addTalkToConference(final Long conferenceId, final Long talkId) {
        /*
    	Conference conference = conferenceRepository.findById(conferenceId).get();
        conference.getTalks().add(talkRepository.findById(talkId).get());
        return conferenceRepository.save(conference);
        */
    	Talk talk = talkRepository.findById(talkId).get();    	
        talk.getConferences().add(conferenceRepository.findById(conferenceId).get());
        talkRepository.save(talk);
        return conferenceRepository.findById(conferenceId).get();
    }

    public Talk addSpeakerToTalk(final Long talkId, final Long speakerId) {
        Talk talk = talkRepository.findById(talkId).get();
        talk.getSpeakers().add(personRepository.findById(speakerId).get());
        return talkRepository.save(talk);
    }

    public Comment addComment(final InputComment comment) throws PermissionException, ValidationException {
        Comment result = null;
        Optional<Talk> talk = talkRepository.findById(comment.getTalkId());

        if (talk.isPresent()) {
            result = commentRepository.save(new Comment(comment.getComment(), comment.getCreatedOn() != null ? comment.getCreatedOn() : OffsetDateTime.now(), comment.getAuthor(), talk.get()));
            commentPublisher.publish(result);
        } else {        	
        	throw new ValidationException(ErrorCodeEnum.TALK_ID_NOT_FOUND);
        }

        return result;
    }

}