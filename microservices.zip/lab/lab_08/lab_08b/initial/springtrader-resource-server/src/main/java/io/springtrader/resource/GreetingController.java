package io.springtrader.resource;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;

@RestController
public class GreetingController  {

    @RequestMapping("/greeting")
    public Object greeting() {
        return Collections.singletonMap("content", "Hello user");
    }

}
