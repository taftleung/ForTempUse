package com.hsbc.glcm.graphqlapi.service;

import com.hsbc.glcm.graphqlapi.model.Talk;

import java.util.List;
import java.util.Optional;

public interface TalkService {

    List<Talk> find(Talk talk);

    Optional<Talk> findById(Long id);

    Talk save(Talk talk);
}