package com.hsbc.glcm.graphqlapi.misc;

import graphql.ErrorClassification;
import graphql.GraphQLError;
import graphql.GraphqlErrorBuilder;
import graphql.language.SourceLocation;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ExceptionHandler;

import javax.xml.transform.Source;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

@Component
public class ExceptionHandlers {

    public enum DefaultErrorClassification implements ErrorClassification {
        ServerError,
        AuthenticationError,
        ApplicationLogicError
    }

    @ExceptionHandler(RuntimeException.class)
    public GraphQLError exceptionHandler(RuntimeException exception) {
        Throwable e = exception.getCause();
        if (e instanceof PermissionException) {
            return exceptionHandler((PermissionException) e);
        } else if (e instanceof ValidationException) {
            return exceptionHandler((ValidationException) e);
        } else {
            return GraphqlErrorBuilder.newError().message("Internal Server Error(s) while executing query").build();
        }
    }

    @ExceptionHandler(PermissionException.class)
    public GraphQLError exceptionHandler(PermissionException exception) {
        return GraphqlErrorBuilder.newError().message(exception.getMessage()).errorType(DefaultErrorClassification.AuthenticationError).extensions(Map.of("source", toSourceLocation(exception), "custom_field_1", "custom_value_1", "custom_field_2", "custom_value_2")).build();
    }

    @ExceptionHandler(ValidationException.class)
    public GraphQLError exceptionHandler(ValidationException exception) {
        return GraphqlErrorBuilder.newError().message(exception.getMessage()).errorType(DefaultErrorClassification.ApplicationLogicError).extensions(Map.of("errorCode", exception.getErrorCode())).build();
    }

    private SourceLocation toSourceLocation(Throwable t) {
        if (t.getStackTrace().length == 0) {
            return null;
        }
        StackTraceElement st = t.getStackTrace()[0];
        return new SourceLocation(st.getLineNumber(), -1, st.toString());
    }
}
