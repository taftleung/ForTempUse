package com.hsbc.glcm.graphqlapi.misc;

public class ValidationException extends Exception {
	
	private final int errorCode;
	private boolean suppressStacktrace = false;

	//Do not suggest to use this
    public ValidationException(int errorCode, String errorMessage, boolean suppressStacktrace) {
    	super(errorMessage, null, suppressStacktrace, !suppressStacktrace);
    	this.suppressStacktrace = suppressStacktrace;
        this.errorCode = errorCode;
    }
    
    public ValidationException(ErrorCode errorCode) {
    	super(errorCode.getErrorMessage(), null, true, !true);
    	this.suppressStacktrace = true;
        this.errorCode = errorCode.getErrorCode();
    }
    
    @Override
    public String toString() {
        if (suppressStacktrace) {
            return getLocalizedMessage();
        } else {
            return super.toString();
        }
    }
    
    public int getErrorCode() {
        return this.errorCode;
    }
}