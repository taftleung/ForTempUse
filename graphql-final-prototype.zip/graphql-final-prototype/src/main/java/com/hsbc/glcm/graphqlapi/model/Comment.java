package com.hsbc.glcm.graphqlapi.model;

import lombok.*;
import javax.persistence.*;
import java.time.OffsetDateTime;

@Entity
@Data
@RequiredArgsConstructor
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class Comment extends BaseEntity {

    @NonNull
    @Column(columnDefinition = "TEXT")
    private String comment;
    
    private OffsetDateTime createdOn;

    private String author;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "talk_id")
    private Talk talk;
    
    public void setCreatedOn(OffsetDateTime createdOn) {
    	this.createdOn = createdOn.withNano(0);
    }
    
    public OffsetDateTime getCreatedOn() {
    	return this.createdOn.withNano(0);
    }

}