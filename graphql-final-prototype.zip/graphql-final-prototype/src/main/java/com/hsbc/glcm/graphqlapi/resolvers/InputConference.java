package com.hsbc.glcm.graphqlapi.resolvers;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.hsbc.glcm.graphqlapi.model.Conference;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InputConference {

    private String name;
    private String city;

    public static Conference convert(InputConference conference) {
        return conference != null ? new Conference(conference.getName(), conference.getCity(), null) : null;

    }

    Conference convert() {
        return convert(this);
    }
}
