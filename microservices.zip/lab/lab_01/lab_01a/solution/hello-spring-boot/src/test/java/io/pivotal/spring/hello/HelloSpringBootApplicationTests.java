package io.pivotal.spring.hello;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@WebMvcTest(HelloSpringBootApplication.class)
public class HelloSpringBootApplicationTests {

    @Test
    public void contextLoads() {
    }

}
