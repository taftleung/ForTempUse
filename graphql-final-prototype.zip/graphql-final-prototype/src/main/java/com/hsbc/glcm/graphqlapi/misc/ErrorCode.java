package com.hsbc.glcm.graphqlapi.misc;

import lombok.Getter;

@Getter
public final class ErrorCode {
	
	private int errorCode;
    private String errorMessage; 
	
	// Prevents instantiation
    private ErrorCode(int errorCode, String errorMessage) {
    	this.errorCode = errorCode;
    	this.errorMessage = errorMessage;
    }

    // Add Error Code and Message here
    public static final ErrorCode TALK_ID_NOT_FOUND = new ErrorCode(900010, "Talk ID not found!");
    public static final ErrorCode XXX_YYY_INVALID = new ErrorCode(800050, "your custom error message");
}