package com.hsbc.glcm.graphqlapi.resolvers;

public enum EnumOrderByDirection {
	ASC,
	DESC
}
