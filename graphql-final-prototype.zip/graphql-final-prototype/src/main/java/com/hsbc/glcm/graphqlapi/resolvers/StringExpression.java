package com.hsbc.glcm.graphqlapi.resolvers;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

import com.hsbc.glcm.graphqlapi.model.Conference;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class StringExpression {

    private String equals;
    private String contains;
    private List<String> in;
    
}
