package com.hsbc.glcm.graphqlapi.resolvers;

import lombok.Data;
import lombok.EqualsAndHashCode;
import com.hsbc.glcm.graphqlapi.model.Conference;
import org.springframework.data.domain.Page;

import java.util.List;

@Data
@EqualsAndHashCode
public class ConferencePageableResponse extends PageableResponse {

    private List<Conference> content;

    public ConferencePageableResponse(Page<Conference> page) {
        super(page);
        this.content = page.getContent();
    }
}
