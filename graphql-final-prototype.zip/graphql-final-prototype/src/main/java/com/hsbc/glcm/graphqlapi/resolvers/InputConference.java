package com.hsbc.glcm.graphqlapi.resolvers;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;

import com.hsbc.glcm.graphqlapi.model.Conference;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InputConference {

    private String name;
    private String city;
    private Integer noOfTicket;
    private OffsetDateTime startDate;
    
    Conference convert() {
        return convert(this);
    }

    public static Conference convert(InputConference conference) {
        return conference != null ? new Conference(conference.getName(), conference.getCity(), conference.getNoOfTicket(), conference.getStartDate() != null ? conference.getStartDate() : OffsetDateTime.now().withNano(0), null) : null;
    }

    public void setStartDate(String string) {
    	OffsetDateTime offsetDatetime;
    	try {
    		offsetDatetime = OffsetDateTime.parse(string);
    	} catch (Exception e) {
    		offsetDatetime = null;
    	}
    	this.startDate = offsetDatetime;
    }
}
