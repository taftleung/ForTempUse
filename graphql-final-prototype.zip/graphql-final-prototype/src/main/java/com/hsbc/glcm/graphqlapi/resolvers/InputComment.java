package com.hsbc.glcm.graphqlapi.resolvers;

import java.time.OffsetDateTime;

import com.hsbc.glcm.graphqlapi.model.Comment;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InputComment {
	
    private String comment;
    private OffsetDateTime createdOn;
    private String author;
    private Long talkId;
}
