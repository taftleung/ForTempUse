package com.daikit.graphql.spring.jpa.demo.entity;

/**
 * Enumeration
 *
 * @author Thibaut Caselli
 */
public enum Enum1 {
	/**
	 * Value 1
	 */
	VAL1,
	/**
	 * Value 2
	 */
	VAL2,
	/**
	 * Value 3
	 */
	VAL3
}
