INSERT INTO orders (orderId, accountId, symbol, orderFee, completionDate, orderType, price, quantity) VALUES (1, 'johnsmith', 'EMC', 1,'2016-12-12',1, 10, 10);
INSERT INTO orders (orderId, accountId, symbol, orderFee, completionDate, orderType, price, quantity) VALUES (1, 'pauljones3', 'MSFT', 1,'2016-10-12',1, 10, 10);

