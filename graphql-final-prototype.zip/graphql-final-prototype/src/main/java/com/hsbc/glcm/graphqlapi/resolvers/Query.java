package com.hsbc.glcm.graphqlapi.resolvers;

import com.coxautodev.graphql.tools.GraphQLQueryResolver;
import com.hsbc.glcm.graphqlapi.model.Comment;
import com.hsbc.glcm.graphqlapi.model.Conference;
import com.hsbc.glcm.graphqlapi.model.Person;
import com.hsbc.glcm.graphqlapi.model.Talk;
import com.hsbc.glcm.graphqlapi.service.CommentRepository;
import com.hsbc.glcm.graphqlapi.service.ConferenceService;
import com.hsbc.glcm.graphqlapi.service.PersonService;
import com.hsbc.glcm.graphqlapi.service.TalkService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public class Query implements GraphQLQueryResolver {


    @Autowired
    private TalkService talkService;

    @Autowired
    private ConferenceService conferenceService;

    @Autowired
    private PersonService personService;

    @Autowired
    private CommentRepository commentRepository;

    public List<Person> persons(final InputPerson filter) {
        return personService.find(InputPerson.convert(filter));
    }

    public Optional<Person> person(final Long id) {
        return personService.findById(id);
    }

    public List<Talk> talks(final InputTalk filter) {
        return talkService.find(InputTalk.convert(filter));
    }

    public Optional<Talk> talk(final Long id) {
        return talkService.findById(id);
    }
    
    //This one is depreciated
    /*
    public List<Conference> conferences(final InputConference filter) {
        return conferenceService.find(InputConference.convert(filter));
    }
	*/
    public ConferencePageableResponse conferences(final InputConference filter, final InputPage inputPage, final List<InputOrderBy> inputOrderByList) {
    	Page<Conference> conferences = conferenceService.find(InputConference.convert(filter), InputPage.convert(inputPage, inputOrderByList));
        return new ConferencePageableResponse(conferences);
    }
    
    public Optional<Conference> conference(final Long id) {
        return conferenceService.findById(id);
    }
    
    public CommentPageableResponse comments(final InputPage inputPage) {
        Page<Comment> comments = commentRepository.findAll(InputPage.convert(inputPage));
        return new CommentPageableResponse(comments);
    }

    public Optional<Comment> comment(final Long id) {
        return commentRepository.findById(id);
    }

}
