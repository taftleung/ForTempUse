package com.hsbc.glcm.graphqlapi.service;

import com.hsbc.glcm.graphqlapi.model.Conference;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface ConferenceService {

	Page<Conference> find(Conference conference, Pageable pageable);

    List<Conference> find(Conference conference);

    Optional<Conference> findById(Long id);

    Conference save(Conference conference);
}