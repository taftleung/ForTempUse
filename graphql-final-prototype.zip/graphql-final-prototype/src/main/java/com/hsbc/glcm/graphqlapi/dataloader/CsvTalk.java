package com.hsbc.glcm.graphqlapi.dataloader;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.hsbc.glcm.graphqlapi.model.Conference;
import com.hsbc.glcm.graphqlapi.model.Person;
import com.hsbc.glcm.graphqlapi.model.Talk;
import com.hsbc.glcm.graphqlapi.service.ConferenceService;
import com.hsbc.glcm.graphqlapi.service.PersonService;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CsvTalk {

    private String title;
    private String summary;
    private String conferences;
    private String speakers;

    public Talk convert(ConferenceService conferenceService, PersonService personService) {
        List<Conference> conferencesList = new ArrayList<>();
        for (String name : StringUtils.split(conferences, ",")) {
            conferencesList.addAll(conferenceService.find(new Conference(name, null, null)));
        }

        List<Person> speakersList = new ArrayList<>();
        for (String name : StringUtils.split(speakers, ",")) {
            speakersList.addAll(personService.find(new Person(name, null, null, null)));
        }

        return new Talk(this.title, this.summary, speakersList, conferencesList);

    }


}
