package com.hsbc.glcm.graphqlapi.misc;

public class Exceptions {

    public static RuntimeException toRuntimeException(Exception exception) {
        return new RuntimeException(exception);
    }
}
