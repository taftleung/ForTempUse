package com.hsbc.glcm.graphqlapi.resolvers;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.domain.Specification;

import com.hsbc.glcm.graphqlapi.model.Conference;
import com.intuit.graphql.filter.client.ExpressionFormat;
import com.intuit.graphql.filter.client.FilterExpression;

import graphql.schema.DataFetchingEnvironment;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FilterConference {

    private StringExpression name;
    private StringExpression city;
    private IntExpression noOfTicket;
    private DateTimeExpression startDate;
    
    private List<FilterConference> and;
    private List<FilterConference> or;
    private FilterConference not;
    
    public static Specification<Conference> convert(DataFetchingEnvironment dataFetchingEnvironment) {
    	Map<String, Object> filter  = new HashMap<String, Object>() {{
    	    put("filter", dataFetchingEnvironment.getArguments().get("filter"));
    	}};
    	
    	FilterExpression.FilterExpressionBuilder builder = FilterExpression.newFilterExpressionBuilder();
    	FilterExpression filterExpression = builder.args(filter).build();	    
    	return filterExpression.getExpression(ExpressionFormat.JPA);
    }
        
}
