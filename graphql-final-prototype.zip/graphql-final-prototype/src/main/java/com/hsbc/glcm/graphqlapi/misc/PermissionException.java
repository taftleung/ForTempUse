package com.hsbc.glcm.graphqlapi.misc;

public class PermissionException extends Exception {

    public PermissionException(String message) {
        super(message);
    }
}
