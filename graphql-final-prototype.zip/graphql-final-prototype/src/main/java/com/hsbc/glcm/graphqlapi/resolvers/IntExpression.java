package com.hsbc.glcm.graphqlapi.resolvers;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

import com.hsbc.glcm.graphqlapi.model.Conference;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class IntExpression {
	private Integer eq;
	private Integer gt;
	private Integer gte;
	private Integer lt;
	private Integer lte;
	private List<Integer> in;
	private List<Integer> between;

}
