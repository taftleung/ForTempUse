package com.hsbc.glcm.graphqlapi.resolvers;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InputPage {

    private int page;
    private int size;
      
    static PageRequest convert(InputPage inputPage) {
    	return convert(inputPage, null);
    }

    static PageRequest convert(InputPage inputPage, List<InputOrderBy> inputOrderByList) {    	
    	return inputPage != null ? PageRequest.of((inputPage.page - 1), inputPage.size, InputOrderBy.convert(inputOrderByList)) : PageRequest.of(0, 20);
    }
}
