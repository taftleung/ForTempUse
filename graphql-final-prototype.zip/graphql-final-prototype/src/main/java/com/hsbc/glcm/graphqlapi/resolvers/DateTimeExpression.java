package com.hsbc.glcm.graphqlapi.resolvers;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;
import java.util.List;

import com.hsbc.glcm.graphqlapi.model.Conference;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DateTimeExpression {
	private OffsetDateTime eq;
	private OffsetDateTime gt;
	private OffsetDateTime gte;
	private OffsetDateTime lt;
	private OffsetDateTime lte;
	private List<OffsetDateTime> between;

}
