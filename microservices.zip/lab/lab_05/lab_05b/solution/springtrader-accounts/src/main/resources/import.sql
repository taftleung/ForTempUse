INSERT INTO account (id, address, passwd, userid, email, creditcard, fullname, openbalance, balance, logincount, logoutcount) VALUES (1, '45 Test Dr.', '123', 'johnsmith','john@pivotal.io','999999999', 'John Smith', 1200.50, 1200.50, 0, 0);
INSERT INTO account (id, address, passwd, userid, email, creditcard, fullname, openbalance, balance, logincount, logoutcount) VALUES (2, '40 Test Dr.', '123', 'pauljones3','paul@pivotal.io','999999999', 'Paul Jones', 1000, 1000, 0, 0);


