package com.hsbc.glcm.graphqlapi.resolvers;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InputPaging {

    private int page;
    private int size;
      
    static PageRequest convert(InputPaging inputPaging) {
    	return convert(inputPaging, null);
    }

    static PageRequest convert(InputPaging inputPaging, List<InputOrderBy> inputOrderByList) {
    	if (inputPaging != null && inputOrderByList != null) {
    		return PageRequest.of((inputPaging.page - 1), inputPaging.size, InputOrderBy.convert(inputOrderByList));
    	} else if (inputPaging != null && inputOrderByList == null) {
    		return PageRequest.of((inputPaging.page - 1), inputPaging.size);
	    } else if (inputPaging == null && inputOrderByList != null) {
	    	return PageRequest.of(0, 20, InputOrderBy.convert(inputOrderByList));
	    } else {
	    	return PageRequest.of(0, 20);
	    }
	}
}
